Jessica Hilario 013944279
Joel Rodriguez 015222816
Project 1/HM 1

For this project, we utilized a struct that held the row and column number of a 3x3 matrix and multiplied threads together to get the resulting 3x3 matrix given the 2 input matrices. Making the matrix multiplication, we used an array of the struct and passed through the struct at a certain index. We used istringstream to convert a string to an int to store the file's content inside the matrices.

For this project, use the makefile that has been stored with this project since the .cpp name of the name is different from the makefile given in the original folder. As said in class, to run this program use the command './Aprog inputA1.in inputA2.in' to display the resulting matrix.

For the contribution of the code, Joel wrote the print statements, reading the matrices from the file, and initialized the necessary variable needed such as the matrices and threads. Jessica joined the threads, made the matrix multiplication algorithm, and created the struct.
