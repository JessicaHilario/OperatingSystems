Jessica Hilario 013944279
Joel Rodriguez 015222816
Project 1/HM 1

For this project, we utilized many online resources and class 
notes to build a shell within a shell. We are asked to use 
the commands cp, ls -l, and kill. We also implemented an exit
function to easily exit out of the shell.

To run this program, run the ./Aprog and the shell will pop up
and ready to run.

For the contribution of this prject, Joel and Jessica worked on 
the project collaboratively doing research online and combining
the work we have found online to compile into one code. Jessica 
developed the shell with the current working directory, 
and validating and executing the commands within the proper
process. Joel did the documentation of the document and code 
format.
